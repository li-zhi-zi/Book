﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Contact_Manage
{
    public partial class 更换头像 : Form
    {
        public 更换头像()
        {
            InitializeComponent();
        }

        private void btt_Select_Image_Click(object sender, EventArgs e)
        {
            //自定义OpenFileDialog打开Windows文件对话框选择文件，并保存路径
            OpenFileDialog f = new OpenFileDialog();
            f.InitialDirectory = Application.StartupPath + @"\images";
            f.Filter = "All files (*.*)|*.*|txt files (*.txt)|*.txt";
            f.FilterIndex = 1;
            f.RestoreDirectory = true;
            if (f.ShowDialog() == DialogResult.OK)
            {
                pictrB_Image.SizeMode = PictureBoxSizeMode.StretchImage;

            }
            return;
        }

        private void btt_Change_Image_Click(object sender, EventArgs e)
        {
            if (pictrB_Image.Image != null)
            {
                string sqlcon = "server=(local);database=library;Trusted_Connection=SSPI;Connection Reset=FALSE";
                String sqlcom2 = "update users set uImage='" + "' where uName='" + 登录.txtLogin_Username + "'";
                SqlConnection con = new SqlConnection(sqlcon);
                SqlCommand com2 = new SqlCommand(sqlcom2, con);
                con.Open();

                    MessageBox.Show("头像更换成功！");
                    this.Close();

            }
            else MessageBox.Show("请选择图片!");
            
        }

        private void Change_Image_Load(object sender, EventArgs e)
        {

        }

        private void pictrB_Image_Click(object sender, EventArgs e)
        {

        }
    }
}
