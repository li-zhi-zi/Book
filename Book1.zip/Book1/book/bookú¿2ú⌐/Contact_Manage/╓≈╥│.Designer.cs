﻿namespace Contact_Manage
{
    partial class 主页
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(主页));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.图书管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btt_Add_Contact = new System.Windows.Forms.ToolStripMenuItem();
            this.书籍查询 = new System.Windows.Forms.ToolStripMenuItem();
            this.查询书籍ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.书籍注销ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.用户管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.修改密码ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.更换头像ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.更换昵称ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.xxx = new System.Windows.Forms.ToolStripStatusLabel();
            this.timer = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.图书管理ToolStripMenuItem,
            this.用户管理ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(948, 28);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 图书管理ToolStripMenuItem
            // 
            this.图书管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btt_Add_Contact,
            this.书籍查询,
            this.查询书籍ToolStripMenuItem,
            this.书籍注销ToolStripMenuItem1});
            this.图书管理ToolStripMenuItem.Name = "图书管理ToolStripMenuItem";
            this.图书管理ToolStripMenuItem.Size = new System.Drawing.Size(81, 24);
            this.图书管理ToolStripMenuItem.Text = "图书管理";
            // 
            // btt_Add_Contact
            // 
            this.btt_Add_Contact.Name = "btt_Add_Contact";
            this.btt_Add_Contact.Size = new System.Drawing.Size(144, 26);
            this.btt_Add_Contact.Text = "新书入库";
            this.btt_Add_Contact.Click += new System.EventHandler(this.btt_Add_Contact_Click_1);
            // 
            // 书籍查询
            // 
            this.书籍查询.Name = "书籍查询";
            this.书籍查询.Size = new System.Drawing.Size(144, 26);
            this.书籍查询.Text = "书籍查询";
            this.书籍查询.Click += new System.EventHandler(this.书籍注销ToolStripMenuItem_Click);
            // 
            // 查询书籍ToolStripMenuItem
            // 
            this.查询书籍ToolStripMenuItem.Name = "查询书籍ToolStripMenuItem";
            this.查询书籍ToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
            this.查询书籍ToolStripMenuItem.Text = "书籍修改";
            this.查询书籍ToolStripMenuItem.Click += new System.EventHandler(this.查询书籍ToolStripMenuItem_Click);
            // 
            // 书籍注销ToolStripMenuItem1
            // 
            this.书籍注销ToolStripMenuItem1.Name = "书籍注销ToolStripMenuItem1";
            this.书籍注销ToolStripMenuItem1.Size = new System.Drawing.Size(144, 26);
            this.书籍注销ToolStripMenuItem1.Text = "书籍注销";
            this.书籍注销ToolStripMenuItem1.Click += new System.EventHandler(this.书籍注销ToolStripMenuItem1_Click);
            // 
            // 用户管理ToolStripMenuItem
            // 
            this.用户管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.修改密码ToolStripMenuItem,
            this.更换头像ToolStripMenuItem,
            this.更换昵称ToolStripMenuItem});
            this.用户管理ToolStripMenuItem.Name = "用户管理ToolStripMenuItem";
            this.用户管理ToolStripMenuItem.Size = new System.Drawing.Size(81, 24);
            this.用户管理ToolStripMenuItem.Text = "用户管理";
            // 
            // 修改密码ToolStripMenuItem
            // 
            this.修改密码ToolStripMenuItem.Name = "修改密码ToolStripMenuItem";
            this.修改密码ToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
            this.修改密码ToolStripMenuItem.Text = "修改密码";
            this.修改密码ToolStripMenuItem.Click += new System.EventHandler(this.修改密码ToolStripMenuItem_Click);
            // 
            // 更换头像ToolStripMenuItem
            // 
            this.更换头像ToolStripMenuItem.Name = "更换头像ToolStripMenuItem";
            this.更换头像ToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
            this.更换头像ToolStripMenuItem.Text = "更换头像";
            this.更换头像ToolStripMenuItem.Click += new System.EventHandler(this.更换头像ToolStripMenuItem_Click);
            // 
            // 更换昵称ToolStripMenuItem
            // 
            this.更换昵称ToolStripMenuItem.Name = "更换昵称ToolStripMenuItem";
            this.更换昵称ToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
            this.更换昵称ToolStripMenuItem.Text = "更换昵称";
            this.更换昵称ToolStripMenuItem.Click += new System.EventHandler(this.更换昵称ToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.xxx,
            this.timer});
            this.statusStrip1.Location = new System.Drawing.Point(0, 397);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(948, 25);
            this.statusStrip1.TabIndex = 6;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(84, 20);
            this.toolStripStatusLabel1.Text = "当前时间：";
            // 
            // xxx
            // 
            this.xxx.Name = "xxx";
            this.xxx.Size = new System.Drawing.Size(0, 20);
            // 
            // timer
            // 
            this.timer.Name = "timer";
            this.timer.Size = new System.Drawing.Size(33, 20);
            this.timer.Text = "xxx";
            // 
            // 主页
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(948, 422);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "主页";
            this.Text = "主页";
            this.Load += new System.EventHandler(this.Menu_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 图书管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem btt_Add_Contact;
        private System.Windows.Forms.ToolStripMenuItem 书籍查询;
        private System.Windows.Forms.ToolStripMenuItem 查询书籍ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 书籍注销ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 用户管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 修改密码ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 更换头像ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 更换昵称ToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel xxx;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStripStatusLabel timer;
    }
}