﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;


namespace Contact_Manage
{
    public partial class 图书管理 : Form
    {
        //数据库连接字符串
        string sqlcon = "server=(local);database=library;Trusted_Connection=SSPI;Connection Reset=FALSE";
        public 图书管理()
        {
            InitializeComponent();
        }
        //查询事件
        private void button1_Click(object sender, EventArgs e)
        {
            string condition = " 1=1";
            //书名
            if (b_Name.Text != "")
                condition = condition + " and bName like'" + b_Name.Text + "%'";
            //作者
            if (b_Author.Text != "")
                condition = condition + " and bAuthor like'" + b_Author.Text + "%'";
            //出版年月
            if (b_PubDat.Text != "")
                condition = condition + " and bPubDat like'" + b_PubDat.Text + "%'";
            //价格
            if (b_Price.Text != "")
                condition = condition + " and bPrice like'" + b_Price.Text + "%'";
            //序列号
            if (b_Num.Text != "")
            {
                condition = condition + " and bNum='" + b_Num.Text + "'";
            } 
            //出版社
            if (b_PubCom.Text != "")
            {
                condition = condition + " and bPubCom='" + b_PubCom.Text + "'";
            } 
            //数量
            if (b_Tag.Text != "")
            {
                condition = condition + " and bTag='" + b_Tag.Text + "'";
            }

            //显示数据库内容
            string sqlcom = "select * from books where" + condition;
            SqlConnection con = new SqlConnection(sqlcon);
            con.Open();
            SqlDataAdapter adapter = new SqlDataAdapter(sqlcom, con);
            DataSet ds = new DataSet();
            adapter.Fill(ds,"cs");
            dataGridView1.DataSource = ds.Tables["cs"];

            con.Close();



            //显示书名
            U_Name.Text = 登录.txtLogin_Username;
        
            String sqlcom2 = "select uImage from users where uName='" + 登录.txtLogin_Username + "'";
            SqlConnection con2 = new SqlConnection(sqlcon);
            SqlCommand com2 = new SqlCommand(sqlcom2, con2);
            con2.Open();
            object obj = com2.ExecuteScalar();
            String image_Path = obj.ToString();

            con2.Close();
           

        }

        //修改事件
        private void btt_Modification_Click(object sender, EventArgs e)
        {

            //获取要修改书籍的序列号
            String modification_ID = b_Num.Text;
            //文本为空判断
            if (modification_ID != "")
            {
                String condition = "";
                //作者
                if (b_Author.Text != "")
                    condition = condition + ",bAuthor='" + b_Author.Text + "'";
                //出版年月
                if (b_PubDat.Text != "")
                    condition = condition + ",bPubDat='" + b_PubDat.Text + "'";
                //价格
                if (b_Price.Text != "")
                    condition = condition + ",bPrice='" + b_Price.Text + "'";
                //出版社
                if (b_PubCom.Text != "")
                    condition = condition + ",bPubCom='" + b_PubCom.Text + "'";
                //数量
                if (b_Tag.Text != "")
                    condition = condition + ",bTag='" + b_Tag.Text + "'";

                String sqlcom = "update books set bName='" + b_Name.Text + "'" + condition + " where bNum = '" + modification_ID + "'";

                SqlConnection con = new SqlConnection(sqlcon);
                SqlCommand com = new SqlCommand(sqlcom, con);
                con.Open();
                int eq = com.ExecuteNonQuery();
                if (eq != 0)
                {
                    MessageBox.Show("修改成功！");
                }
                else MessageBox.Show("修改失败！");
                con.Close();
                
                foreach (Control item in this.Controls)
                {
                    if (item is TextBox)
                    {
                        item.Text = "";
                    }
                }
            }
            else MessageBox.Show("请先点击联系人再进行修改操作！");

        }

        //删除事件
        private void btt_Delete_Click(object sender, EventArgs e)
        {
            //获取书籍序列号
            String delete_ID = b_Num.Text;

            //连接数据库删除书籍
            String sqlcom = "delete from books where bNum='" + delete_ID + "'";
            SqlConnection con = new SqlConnection(sqlcon);
            SqlCommand com = new SqlCommand(sqlcom, con);
            con.Open();
            int eq = com.ExecuteNonQuery();
            if (eq != 0)
            {
                MessageBox.Show("删除成功");
            }
            else MessageBox.Show("删除失败");
            con.Close();
        }
        
        private void tB_Name_MouseClick(object sender, MouseEventArgs e)
        {
            //管理员昵称
            U_Name.Text = 登录.txtLogin_Username;

            String sqlcom = "select uImage from users where uName='" + 登录.txtLogin_Username + "'";
            SqlConnection con = new SqlConnection(sqlcon);
            SqlCommand com = new SqlCommand(sqlcom, con);
            con.Open();
            object obj = com.ExecuteScalar();
            String image_Path = obj.ToString();

            con.Close();
            
        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            b_Num.Text = this.dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            b_Name.Text = this.dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            b_Author.Text = this.dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString(); 
            b_PubCom.Text = this.dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
            b_PubDat.Text = this.dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
            b_Price.Text = this.dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
            b_Tag.Text = this.dataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString();
        }

        private void Contact_Manage_Load(object sender, EventArgs e)
        {

        }

        private void tB_Phone_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
