﻿namespace Contact_Manage
{
    partial class 图书管理
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(图书管理));
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.b_Name = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.b_Price = new System.Windows.Forms.TextBox();
            this.b_Author = new System.Windows.Forms.TextBox();
            this.b_PubDat = new System.Windows.Forms.TextBox();
            this.btt_Delete = new System.Windows.Forms.Button();
            this.btt_Modification = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.b_Num = new System.Windows.Forms.TextBox();
            this.U_Name = new System.Windows.Forms.Label();
            this.pctrB_Image = new System.Windows.Forms.PictureBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label6 = new System.Windows.Forms.Label();
            this.b_Tag = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.b_PubCom = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pctrB_Image)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(940, 125);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 29);
            this.button1.TabIndex = 0;
            this.button1.Text = "查 询";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(282, 361);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "书名：";
            // 
            // b_Name
            // 
            this.b_Name.Location = new System.Drawing.Point(331, 358);
            this.b_Name.Margin = new System.Windows.Forms.Padding(4);
            this.b_Name.Name = "b_Name";
            this.b_Name.Size = new System.Drawing.Size(195, 25);
            this.b_Name.TabIndex = 2;
            this.b_Name.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tB_Name_MouseClick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(556, 361);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "作者：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(7, 420);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "出版年月：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Location = new System.Drawing.Point(282, 420);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 15);
            this.label4.TabIndex = 5;
            this.label4.Text = "价格：";
            // 
            // b_Price
            // 
            this.b_Price.Location = new System.Drawing.Point(362, 417);
            this.b_Price.Margin = new System.Windows.Forms.Padding(4);
            this.b_Price.Name = "b_Price";
            this.b_Price.Size = new System.Drawing.Size(164, 25);
            this.b_Price.TabIndex = 6;
            // 
            // b_Author
            // 
            this.b_Author.Location = new System.Drawing.Point(606, 358);
            this.b_Author.Margin = new System.Windows.Forms.Padding(4);
            this.b_Author.Name = "b_Author";
            this.b_Author.Size = new System.Drawing.Size(155, 25);
            this.b_Author.TabIndex = 7;
            this.b_Author.TextChanged += new System.EventHandler(this.tB_Phone_TextChanged);
            // 
            // b_PubDat
            // 
            this.b_PubDat.Location = new System.Drawing.Point(83, 417);
            this.b_PubDat.Margin = new System.Windows.Forms.Padding(4);
            this.b_PubDat.Name = "b_PubDat";
            this.b_PubDat.Size = new System.Drawing.Size(162, 25);
            this.b_PubDat.TabIndex = 8;
            // 
            // btt_Delete
            // 
            this.btt_Delete.Location = new System.Drawing.Point(940, 238);
            this.btt_Delete.Margin = new System.Windows.Forms.Padding(4);
            this.btt_Delete.Name = "btt_Delete";
            this.btt_Delete.Size = new System.Drawing.Size(100, 29);
            this.btt_Delete.TabIndex = 10;
            this.btt_Delete.Text = "删 除";
            this.btt_Delete.UseVisualStyleBackColor = true;
            this.btt_Delete.Click += new System.EventHandler(this.btt_Delete_Click);
            // 
            // btt_Modification
            // 
            this.btt_Modification.Location = new System.Drawing.Point(940, 178);
            this.btt_Modification.Margin = new System.Windows.Forms.Padding(4);
            this.btt_Modification.Name = "btt_Modification";
            this.btt_Modification.Size = new System.Drawing.Size(100, 29);
            this.btt_Modification.TabIndex = 11;
            this.btt_Modification.Text = "修 改";
            this.btt_Modification.UseVisualStyleBackColor = true;
            this.btt_Modification.Click += new System.EventHandler(this.btt_Modification_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Location = new System.Drawing.Point(7, 361);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 15);
            this.label5.TabIndex = 12;
            this.label5.Text = "序列号：";
            // 
            // b_Num
            // 
            this.b_Num.Location = new System.Drawing.Point(70, 358);
            this.b_Num.Margin = new System.Windows.Forms.Padding(4);
            this.b_Num.Name = "b_Num";
            this.b_Num.ReadOnly = true;
            this.b_Num.Size = new System.Drawing.Size(162, 25);
            this.b_Num.TabIndex = 13;
            // 
            // U_Name
            // 
            this.U_Name.AutoSize = true;
            this.U_Name.BackColor = System.Drawing.Color.Transparent;
            this.U_Name.Location = new System.Drawing.Point(872, 15);
            this.U_Name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.U_Name.Name = "U_Name";
            this.U_Name.Size = new System.Drawing.Size(52, 15);
            this.U_Name.TabIndex = 15;
            this.U_Name.Text = "管理员";
            // 
            // pctrB_Image
            // 
            this.pctrB_Image.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pctrB_Image.BackgroundImage")));
            this.pctrB_Image.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pctrB_Image.Location = new System.Drawing.Point(932, 15);
            this.pctrB_Image.Margin = new System.Windows.Forms.Padding(4);
            this.pctrB_Image.Name = "pctrB_Image";
            this.pctrB_Image.Size = new System.Drawing.Size(119, 89);
            this.pctrB_Image.TabIndex = 16;
            this.pctrB_Image.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(15, 15);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(737, 309);
            this.dataGridView1.TabIndex = 17;
            this.dataGridView1.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_CellMouseClick);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Location = new System.Drawing.Point(556, 417);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 15);
            this.label6.TabIndex = 18;
            this.label6.Text = "数量：";
            // 
            // b_Tag
            // 
            this.b_Tag.Location = new System.Drawing.Point(616, 414);
            this.b_Tag.Margin = new System.Windows.Forms.Padding(4);
            this.b_Tag.Name = "b_Tag";
            this.b_Tag.Size = new System.Drawing.Size(155, 25);
            this.b_Tag.TabIndex = 19;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Location = new System.Drawing.Point(791, 361);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 15);
            this.label7.TabIndex = 20;
            this.label7.Text = "出版社：";
            // 
            // b_PubCom
            // 
            this.b_PubCom.Location = new System.Drawing.Point(866, 358);
            this.b_PubCom.Margin = new System.Windows.Forms.Padding(4);
            this.b_PubCom.Name = "b_PubCom";
            this.b_PubCom.Size = new System.Drawing.Size(155, 25);
            this.b_PubCom.TabIndex = 21;
            // 
            // 图书管理
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1085, 496);
            this.Controls.Add(this.b_PubCom);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.b_Tag);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.pctrB_Image);
            this.Controls.Add(this.U_Name);
            this.Controls.Add(this.b_Num);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btt_Modification);
            this.Controls.Add(this.btt_Delete);
            this.Controls.Add(this.b_PubDat);
            this.Controls.Add(this.b_Author);
            this.Controls.Add(this.b_Price);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.b_Name);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "图书管理";
            this.Text = "图书管理";
            this.Load += new System.EventHandler(this.Contact_Manage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pctrB_Image)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox b_Name;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox b_Price;
        private System.Windows.Forms.TextBox b_Author;
        private System.Windows.Forms.TextBox b_PubDat;
        private System.Windows.Forms.Button btt_Delete;
        private System.Windows.Forms.Button btt_Modification;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox b_Num;
        private System.Windows.Forms.Label U_Name;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.PictureBox pctrB_Image;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox b_Tag;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox b_PubCom;
    }
}