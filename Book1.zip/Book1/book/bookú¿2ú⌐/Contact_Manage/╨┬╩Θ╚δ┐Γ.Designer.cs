﻿namespace Contact_Manage
{
    partial class 新书入库
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(新书入库));
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.b_Num = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.b_Name = new System.Windows.Forms.TextBox();
            this.b_Author = new System.Windows.Forms.TextBox();
            this.b_PubCom = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.b_PubDat = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.b_Price = new System.Windows.Forms.TextBox();
            this.b_Tag = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            resources.ApplyResources(this.button1, "button1");
            this.button1.Name = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Name = "label1";
            // 
            // b_Num
            // 
            resources.ApplyResources(this.b_Num, "b_Num");
            this.b_Num.Name = "b_Num";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Name = "label2";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Name = "label3";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Name = "label4";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // b_Name
            // 
            resources.ApplyResources(this.b_Name, "b_Name");
            this.b_Name.Name = "b_Name";
            // 
            // b_Author
            // 
            resources.ApplyResources(this.b_Author, "b_Author");
            this.b_Author.Name = "b_Author";
            // 
            // b_PubCom
            // 
            resources.ApplyResources(this.b_PubCom, "b_PubCom");
            this.b_PubCom.Name = "b_PubCom";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Name = "label5";
            // 
            // b_PubDat
            // 
            resources.ApplyResources(this.b_PubDat, "b_PubDat");
            this.b_PubDat.Name = "b_PubDat";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Name = "label6";
            // 
            // b_Price
            // 
            resources.ApplyResources(this.b_Price, "b_Price");
            this.b_Price.Name = "b_Price";
            // 
            // b_Tag
            // 
            resources.ApplyResources(this.b_Tag, "b_Tag");
            this.b_Tag.Name = "b_Tag";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Name = "label7";
            // 
            // AddContact
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label7);
            this.Controls.Add(this.b_Tag);
            this.Controls.Add(this.b_Price);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.b_PubDat);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.b_PubCom);
            this.Controls.Add(this.b_Author);
            this.Controls.Add(this.b_Name);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.b_Num);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Name = "AddContact";
            this.Load += new System.EventHandler(this.AddContact_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox b_Num;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox b_Name;
        private System.Windows.Forms.TextBox b_Author;
        private System.Windows.Forms.TextBox b_PubCom;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox b_PubDat;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox b_Price;
        private System.Windows.Forms.TextBox b_Tag;
        private System.Windows.Forms.Label label7;
    }
}