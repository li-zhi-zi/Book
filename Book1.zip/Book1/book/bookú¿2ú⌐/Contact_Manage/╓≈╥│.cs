﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Contact_Manage
{
    public partial class 主页 : Form
    {
        public 主页()
        {
            InitializeComponent();
        }


        private void btt_Add_Contact_Click_1(object sender, EventArgs e)
        {
            新书入库 add = new 新书入库();
            add.Show();
        }

        private void 书籍注销ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            图书管理 query = new 图书管理();
            query.Show();
        }

        private void 查询书籍ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            图书管理 query = new 图书管理();
            query.Show();
        }

        private void 书籍注销ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            图书管理 query = new 图书管理();
            query.Show();
        }

        private void 修改密码ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            修改密码 modif_Pwd = new 修改密码();
            modif_Pwd.Show();
        }

        private void 更换头像ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            更换头像 cImg = new 更换头像();
            cImg.Show();
        }

        private void 更换昵称ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            更换昵称 m = new 更换昵称();
            m.Show();
        }

        private void Menu_Load(object sender, EventArgs e)
        {
            timer.Text = "   " ;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer.Text = DateTime.Now.ToString();
        }
    }
}
