﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Contact_Manage
{

    public partial class 新书入库 : Form
    {
        public 新书入库()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //判断是否为空
            if (b_Num.Text.Length == 0 && b_Author.Text.Length == 0 && b_Name.Text.Length == 0 && b_PubCom.Text.Length == 0 && b_PubDat.Text.Length == 0 && b_Price.Text.Length == 0 && b_Tag.Text.Length == 0)
            {
                MessageBox.Show("信息必须填写完整！");
                return;
            }

            string sqlcon = "server=(local);database=phone_Book;Trusted_Connection=SSPI;Connection Reset=FALSE";
            string sqlcom = "INSERT INTO Contact (Contact_Name,Contact_QQ,Contact_Phone,Contact_Email,Account_Username) VALUES('"
                + b_Num.Text + "','" + b_Name.Text+ "','" + b_Author.Text + "','" + b_PubCom.Text + "','" + b_PubDat.Text + "','" + b_Price.Text + "','" + b_Tag.Text + "','" + 登录.txtLogin_Username + "')";
            //添加
            SqlConnection con = new SqlConnection(sqlcon);
            SqlCommand com = new SqlCommand(sqlcom, con);
            con.Open();

                MessageBox.Show("添加成功!");

            con.Close();

        }

        private void AddContact_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
