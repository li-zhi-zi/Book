﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Contact_Manage
{
    public partial class 更换昵称 : Form
    {
        public 更换昵称()
        {
            InitializeComponent();
        }

        //点击跳出管理员ID
        private void tB_Username_MouseClick(object sender, MouseEventArgs e)
        {
            tB_Username.Text = 登录.txtLogin_Username;
        }

        //点击跳出管理员昵称
        private void tB_NewUsername_MouseClick(object sender, MouseEventArgs e)
        {
            tB_Username.Text = 登录.txtLogin_Username;
        }

        private void btt_Modfct_Username_Click(object sender, EventArgs e)
        {
            //获取新用户名
            String newUsername = tB_NewUsername.Text;
            if (newUsername == "")
            {
                MessageBox.Show("请输入新用户名！");
                return;
            }

            //连接数据库更改管理员昵称
            String sqlcon = "server=(local);database=library;Trusted_Connection=SSPI;Connection Reset=FALSE";
            String sqlcom = "update users set uName='"+newUsername+"' where uName='"+登录.txtLogin_Username+"'";
            SqlConnection con = new SqlConnection(sqlcon);
            SqlCommand com = new SqlCommand(sqlcom, con);
            con.Open();
            int eq=com.ExecuteNonQuery();
            if (eq != 0)
            {
                MessageBox.Show("修改成功!");
                this.Close();
                登录.txtLogin_Username = newUsername;
            }
            else MessageBox.Show("修改失败！");

        }

        private void Mdfct_Acct_Username_Load(object sender, EventArgs e)
        {

        }
    }
}
