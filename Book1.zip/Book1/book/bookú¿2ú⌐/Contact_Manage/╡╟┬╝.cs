﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Contact_Manage
{

    public partial class 登录 : Form
    {
        //存取用户登录名
        public static String txtLogin_Username;
        public 登录()
        {
            InitializeComponent();
        }

        //登录
        private void btt_Login_Click(object sender, EventArgs e)
        {
            //获取用户输入的
            txtLogin_Username = tB_Account_Username.Text;
            String password = tB_Account_Password.Text;

            if (txtLogin_Username == "" || password == "")
            {
                MessageBox.Show("请输入用户名和密码！");
                return;
            }

            //连接数据库
            string sqlcon = "server=(local);database=library;Trusted_Connection=SSPI;Connection Reset=FALSE";
            String sqlcom = " select * from users where uName='" + txtLogin_Username + "' and uPwd='" + password + "'";
            SqlConnection con = new SqlConnection(sqlcon);
            SqlCommand com = new SqlCommand(sqlcom, con);
            con.Open();

            SqlDataReader reader = com.ExecuteReader();
            if (reader.Read())
            {
                //打开菜单页面
                主页 menu = new 主页();
                menu.Show();
            }
            else
            {
                MessageBox.Show("用户名或密码错误，请重新输入！");
            }
            con.Close();

        }

        private void pctrB_Image_Click(object sender, EventArgs e)
        {

        }

       
        }


    }

