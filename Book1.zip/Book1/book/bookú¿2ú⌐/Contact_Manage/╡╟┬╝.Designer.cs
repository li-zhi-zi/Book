﻿namespace Contact_Manage
{
    partial class 登录
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(登录));
            this.btt_Login = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tB_Account_Username = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tB_Account_Password = new System.Windows.Forms.TextBox();
            this.pctrB_Image = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pctrB_Image)).BeginInit();
            this.SuspendLayout();
            // 
            // btt_Login
            // 
            this.btt_Login.Location = new System.Drawing.Point(219, 218);
            this.btt_Login.Margin = new System.Windows.Forms.Padding(4);
            this.btt_Login.Name = "btt_Login";
            this.btt_Login.Size = new System.Drawing.Size(100, 29);
            this.btt_Login.TabIndex = 0;
            this.btt_Login.Text = "登 录";
            this.btt_Login.UseVisualStyleBackColor = true;
            this.btt_Login.Click += new System.EventHandler(this.btt_Login_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(148, 81);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "用户名：";
            // 
            // tB_Account_Username
            // 
            this.tB_Account_Username.Location = new System.Drawing.Point(219, 78);
            this.tB_Account_Username.Margin = new System.Windows.Forms.Padding(4);
            this.tB_Account_Username.Name = "tB_Account_Username";
            this.tB_Account_Username.Size = new System.Drawing.Size(212, 25);
            this.tB_Account_Username.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(156, 131);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "密 码：";
            // 
            // tB_Account_Password
            // 
            this.tB_Account_Password.Location = new System.Drawing.Point(219, 128);
            this.tB_Account_Password.Margin = new System.Windows.Forms.Padding(4);
            this.tB_Account_Password.Name = "tB_Account_Password";
            this.tB_Account_Password.PasswordChar = '*';
            this.tB_Account_Password.Size = new System.Drawing.Size(212, 25);
            this.tB_Account_Password.TabIndex = 4;
            // 
            // pctrB_Image
            // 
            this.pctrB_Image.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pctrB_Image.BackgroundImage")));
            this.pctrB_Image.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pctrB_Image.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pctrB_Image.ErrorImage")));
            this.pctrB_Image.Image = ((System.Drawing.Image)(resources.GetObject("pctrB_Image.Image")));
            this.pctrB_Image.Location = new System.Drawing.Point(30, 67);
            this.pctrB_Image.Margin = new System.Windows.Forms.Padding(4);
            this.pctrB_Image.Name = "pctrB_Image";
            this.pctrB_Image.Size = new System.Drawing.Size(110, 96);
            this.pctrB_Image.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pctrB_Image.TabIndex = 7;
            this.pctrB_Image.TabStop = false;
            this.pctrB_Image.Click += new System.EventHandler(this.pctrB_Image_Click);
            // 
            // 登录
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(620, 331);
            this.Controls.Add(this.pctrB_Image);
            this.Controls.Add(this.tB_Account_Password);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tB_Account_Username);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btt_Login);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "登录";
            this.Text = "图书管理系统（管理员端）";
            ((System.ComponentModel.ISupportInitialize)(this.pctrB_Image)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btt_Login;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tB_Account_Username;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tB_Account_Password;
        private System.Windows.Forms.PictureBox pctrB_Image;
    }
}

